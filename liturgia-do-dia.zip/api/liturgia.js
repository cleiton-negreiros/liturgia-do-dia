// api/liturgia.js
// ─────────────────────────────────────────────────────────────
// Função Serverless (Vercel) que faz scraping da liturgia diária
// Fontes: liturgiadiaria.site (espelho CNBB)
// ─────────────────────────────────────────────────────────────

const axios  = require('axios');
const cheerio = require('cheerio');

// ── Helpers ──────────────────────────────────────────────────

function formatarDataUrl(dataStr) {
  // Recebe "2026-03-04", retorna "04-03-2026" (formato do site)
  const [ano, mes, dia] = dataStr.split('-');
  return `${dia}-${mes}-${ano}`;
}

function limparTexto(texto) {
  return texto
    .replace(/\s+/g, ' ')
    .replace(/^\s+|\s+$/g, '')
    .trim();
}

// ── Scraper principal ─────────────────────────────────────────

async function buscarLiturgia(data) {
  // data = "2026-03-04"
  const dataFormatada = formatarDataUrl(data);
  const url = `https://liturgiadiaria.site/${dataFormatada}`;

  let html;
  try {
    const resposta = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; LiturgiaSite/1.0)',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'pt-BR,pt;q=0.9',
      }
    });
    html = resposta.data;
  } catch (erro) {
    throw new Error(`Não foi possível acessar o site da liturgia: ${erro.message}`);
  }

  const $ = cheerio.load(html);
  const leituras = [];

  // ── Extrai cada seção de leitura ──
  // O site organiza as leituras em blocos com classe .leitura ou similar
  // Vamos capturar os títulos e textos de forma flexível

  // Tenta extrair o tempo litúrgico
  const tempoLiturgico = limparTexto(
    $('.tempo-liturgico, .liturgical-time, h2').first().text() || 'Tempo Comum'
  );

  // Extrai todas as seções de leitura
  const secoes = [];

  $('article, .leitura, .reading, section').each((i, el) => {
    const titulo = limparTexto($(el).find('h2, h3, h4, .titulo').first().text());
    const referencia = limparTexto($(el).find('.referencia, .reference, cite').first().text());
    const texto = limparTexto($(el).find('p, .texto').map((i, p) => $(p).text()).get().join('\n'));

    if (titulo && texto && texto.length > 30) {
      secoes.push({ titulo, referencia, texto });
    }
  });

  // Se o scraping estruturado não encontrou nada, tenta abordagem genérica
  if (secoes.length === 0) {
    // Pega todos os parágrafos de conteúdo principal
    $('main p, .content p, #content p, .post-content p').each((i, el) => {
      const texto = limparTexto($(el).text());
      if (texto.length > 50) {
        leituras.push(texto);
      }
    });
  }

  return {
    data,
    tempoLiturgico,
    url,
    secoes: secoes.length > 0 ? secoes : null,
    textoBruto: leituras.length > 0 ? leituras : null,
    fonte: 'liturgiadiaria.site'
  };
}

// ── Handler do Vercel ─────────────────────────────────────────

module.exports = async function handler(req, res) {
  // Permite chamadas do frontend (CORS)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ erro: 'Método não permitido' });
  }

  // Pega a data da query string, ex: /api/liturgia?data=2026-03-04
  // Se não informada, usa hoje
  let { data } = req.query;

  if (!data) {
    const hoje = new Date();
    data = hoje.toISOString().split('T')[0]; // "2026-03-04"
  }

  // Valida formato da data
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) {
    return res.status(400).json({ erro: 'Formato de data inválido. Use AAAA-MM-DD' });
  }

  try {
    const liturgia = await buscarLiturgia(data);
    return res.status(200).json({ sucesso: true, ...liturgia });
  } catch (erro) {
    console.error('Erro no scraping:', erro.message);
    return res.status(500).json({
      sucesso: false,
      erro: erro.message,
      data
    });
  }
};
